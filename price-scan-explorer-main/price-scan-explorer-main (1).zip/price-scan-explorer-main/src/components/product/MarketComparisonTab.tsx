
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, Loader2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Product } from "@/types";
import { PriceMatchTab } from "./marketplace/PriceMatchTab";
import { ComparisonTableTab } from "./ComparisonTableTab";
import { ProductTableView } from "../ProductTableView";
import { ProductDetailsTab } from "./marketplace/ProductDetailsTab";

interface MarketComparisonTabProps {
  products: Product[];
}

export function MarketComparisonTab({ products }: MarketComparisonTabProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Market & Product Comparison
          </CardTitle>
          <p className="text-sm text-muted-foreground">
            Compare prices across different marketplaces and track product changes over time
          </p>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="price-match" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="price-match">Price Match</TabsTrigger>
              <TabsTrigger value="product-details">Product Details</TabsTrigger>
              <TabsTrigger value="product-comparison">Product Comparison</TabsTrigger>
              <TabsTrigger value="edit-products">Edit Products</TabsTrigger>
            </TabsList>
            <TabsContent value="price-match" className="space-y-4">
              <PriceMatchTab />
            </TabsContent>
            <TabsContent value="product-details" className="space-y-4">
              <ProductDetailsTab />
            </TabsContent>
            <TabsContent value="product-comparison" className="space-y-4">
              <ComparisonTableTab products={products} />
            </TabsContent>
            <TabsContent value="edit-products" className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">Edit Products</h3>
                  <p className="text-sm text-muted-foreground">
                    Edit product information and manage data
                  </p>
                </div>
                <ProductTableView 
                  products={products}
                  onProductUpdate={(productId, updates) => {
                    console.log('Product updated:', productId, updates);
                    // Handle product updates here
                  }}
                />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
