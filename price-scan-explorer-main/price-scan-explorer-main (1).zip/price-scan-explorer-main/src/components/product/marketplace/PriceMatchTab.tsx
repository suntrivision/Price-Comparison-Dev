
import React, { useState } from "react";
import { CardContent } from "@/components/ui/card";
import { Loader2, Database } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { PriceComparisonTable } from "./PriceComparisonTable";
import { DatasetSummary } from "./DatasetSummary";
import { PriceMatchControls } from "./PriceMatchControls";
import { usePriceMatchData } from "./usePriceMatchData";
import { DatasetType } from "./types";

export function PriceMatchTab() {
  const { priceMatchData, csvData, embeddingMatchData, isLoading, refetchData, rawEmbeddingData } = usePriceMatchData();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedDataset, setSelectedDataset] = useState<DatasetType>("both");

  // Combine datasets based on selection
  const getDisplayData = () => {
    switch (selectedDataset) {
      case "original":
        return priceMatchData;
      case "embedding":
        return embeddingMatchData;
      case "both":
        return [...priceMatchData, ...embeddingMatchData];
      default:
        return [];
    }
  };

  // Filter data based on search and category
  const filteredData = getDisplayData().filter(product => {
    const matchesSearch = product.representative_name.toLowerCase().includes(searchQuery.toLowerCase());
    const clusterId = typeof product.cluster_id === 'string' ? parseInt(product.cluster_id) : product.cluster_id;
    const matchesCategory = !selectedCategory || product.category === selectedCategory || 
                           (selectedCategory === "original" && clusterId < 10000) ||
                           (selectedCategory === "embedding_match" && clusterId >= 10000);
    return matchesSearch && matchesCategory;
  });

  // Get unique categories
  const categories = Array.from(new Set([
    ...priceMatchData.map(p => p.category).filter(Boolean),
    ...embeddingMatchData.map(p => p.category).filter(Boolean),
    "original",
    "embedding_match"
  ]));

  const totalProducts = getDisplayData().length;
  const originalCount = priceMatchData.length;
  const embeddingCount = embeddingMatchData.length;

  // Extract clusters data for table display
  const getClustersTableData = () => {
    if (!rawEmbeddingData || !rawEmbeddingData.clusters) return [];
    
    return rawEmbeddingData.clusters.map((cluster: any, index: number) => ({
      cluster_id: cluster.cluster_id || index,
      representative_name: cluster.representative_name || 'N/A',
      product_count: cluster.product_details ? cluster.product_details.length : 0,
      total_products: cluster.total_products || 0,
      best_price: cluster.best_price || 'N/A',
      best_marketplace: cluster.best_marketplace || 'N/A',
      products: cluster.product_details || []
    }));
  };

  const clustersData = getClustersTableData();

  return (
    <div className="space-y-6">
      <DatasetSummary 
        originalCount={originalCount}
        embeddingCount={embeddingCount}
        totalProducts={totalProducts}
      />

      {/* Raw Data Table Section */}
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Database className="h-5 w-5" />
              Embedding Match Data Overview
            </h3>
          </div>
          
          <p className="text-sm text-muted-foreground">
            Structured data from: https://prodpromo.s3.ap-southeast-1.amazonaws.com/thunderbitscrape/embedding_matched_price_comparison.json
          </p>

          <div className="space-y-4">
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin mr-2" />
                <span>Loading data...</span>
              </div>
            ) : clustersData.length > 0 ? (
              <div className="border rounded-md">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Cluster ID</TableHead>
                      <TableHead>Representative Name</TableHead>
                      <TableHead>Product Count</TableHead>
                      <TableHead>Total Products</TableHead>
                      <TableHead>Best Price</TableHead>
                      <TableHead>Best Marketplace</TableHead>
                      <TableHead>Products</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {clustersData.map((cluster, index) => (
                      <TableRow key={cluster.cluster_id || index}>
                        <TableCell>
                          <Badge variant="outline">{cluster.cluster_id}</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs">
                          <div className="truncate" title={cluster.representative_name}>
                            {cluster.representative_name}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{cluster.product_count}</Badge>
                        </TableCell>
                        <TableCell>{cluster.total_products}</TableCell>
                        <TableCell>
                          <span className="font-medium text-green-600">
                            {cluster.best_price !== 'N/A' ? `RM ${cluster.best_price}` : 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{cluster.best_marketplace}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="text-xs text-muted-foreground">
                            {cluster.products.length > 0 ? (
                              <div className="max-w-xs">
                                {cluster.products.slice(0, 2).map((product: any, idx: number) => (
                                  <div key={idx} className="truncate">
                                    {product.name || product.marketplace || 'Product'}
                                  </div>
                                ))}
                                {cluster.products.length > 2 && (
                                  <div>+{cluster.products.length - 2} more</div>
                                )}
                              </div>
                            ) : (
                              'No products'
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No cluster data available
              </div>
            )}
          </div>
        </div>
      </CardContent>

      <CardContent>
        <PriceMatchControls
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          selectedCategory={selectedCategory}
          setSelectedCategory={setSelectedCategory}
          selectedDataset={selectedDataset}
          setSelectedDataset={setSelectedDataset}
          categories={categories}
          originalCount={originalCount}
          embeddingCount={embeddingCount}
          isLoading={isLoading}
          onRefresh={refetchData}
          filteredCount={filteredData.length}
          totalProducts={totalProducts}
        />
      </CardContent>

      {isLoading ? (
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin mr-2" />
          <span>Loading price comparison data...</span>
        </CardContent>
      ) : (
        <PriceComparisonTable 
          data={filteredData} 
          csvData={csvData}
          showCategory={true}
        />
      )}
    </div>
  );
}
