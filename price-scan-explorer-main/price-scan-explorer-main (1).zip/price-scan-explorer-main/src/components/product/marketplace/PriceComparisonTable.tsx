
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, Eye, ChevronLeft, ChevronRight, ArrowUpDown, Globe, Package, Search, Loader2 } from "lucide-react";
import { PriceMatchProduct, CSVProduct } from "./types";
import { extractMarketplaceFromUrl } from "@/lib/marketplaceUtils";

interface PriceComparisonTableProps {
  data?: PriceMatchProduct[];
  csvData?: CSVProduct[];
  showCategory?: boolean;
}

interface S3ComparisonData {
  product_1: string;
  product_1_price: number;
  product_1_marketplace: string;
  product_1_url?: string;
  product_2: string;
  product_2_price: number;
  product_2_marketplace: string;
  product_2_url?: string;
  similarity_score: number;
  similarity_level: string;
  price_difference: number;
  cross_marketplace_match: boolean;
  cheaper_product: string;
  cheaper_marketplace: string;
  cheaper_price: number;
  expensive_price: number;
  savings_percentage: number;
}

interface S3DataStructure {
  summary: {
    total_clusters: number;
    total_products: number;
    total_match_pairs: number;
    [key: string]: any;
  };
  clusters: {
    cluster_id: number;
    match_pairs: S3ComparisonData[];
    [key: string]: any;
  }[];
}

const ITEMS_PER_PAGE = 20;

export function PriceComparisonTable({ data = [], csvData = [], showCategory = false }: PriceComparisonTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  } | null>(null);
  const [s3Data, setS3Data] = useState<S3ComparisonData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch data from S3
  useEffect(() => {
    const fetchS3Data = async () => {
      try {
        setIsLoading(true);
        setError(null);
        
        console.log('Fetching price comparison data from S3...');
        const response = await fetch('https://prodpromo.s3.ap-southeast-1.amazonaws.com/thunderbitscrape/embedding_matched_price_comparison_shopeeLotus.json');
        
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const jsonData: S3DataStructure = await response.json();
        console.log('S3 data received:', jsonData);
        
        // Extract all match_pairs from all clusters
        const allMatchPairs: S3ComparisonData[] = [];
        
        if (jsonData.clusters && Array.isArray(jsonData.clusters)) {
          jsonData.clusters.forEach(cluster => {
            if (cluster.match_pairs && Array.isArray(cluster.match_pairs)) {
              allMatchPairs.push(...cluster.match_pairs);
            }
          });
        }
        
        console.log('Extracted match pairs:', allMatchPairs.length);
        console.log('Sample match pair for URL check:', allMatchPairs[0]);
        setS3Data(allMatchPairs);
      } catch (err) {
        console.error('Error fetching S3 data:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch data');
      } finally {
        setIsLoading(false);
      }
    };

    fetchS3Data();
  }, []);

  const formatPrice = (price: number | string | null) => {
    if (price === null || price === undefined || price === '') return "-";
    
    // Convert to number if it's a string
    const numPrice = typeof price === 'string' ? parseFloat(price.toString().replace(/[^0-9.-]+/g, '')) : price;
    
    // Return formatted price or dash if invalid
    return numPrice > 0 ? `RM ${numPrice.toFixed(2)}` : "-";
  };

  const formatSimilarity = (similarity: number | null) => {
    if (similarity === null || similarity === undefined) return "-";
    return `${similarity.toFixed(1)}%`;
  };

  const getMarketplaceBadgeColor = (marketplace: string) => {
    switch (marketplace?.toLowerCase()) {
      case 'shopee':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'lazada':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'lotus':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'mydin':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
      case 'tiktok':
        return 'bg-pink-100 text-pink-800 dark:bg-pink-900 dark:text-pink-200';
      case 'giant':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'aeon':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  // Sort data
  const sortedData = React.useMemo(() => {
    if (!sortConfig) return s3Data;

    return [...s3Data].sort((a, b) => {
      let aValue = a[sortConfig.key as keyof S3ComparisonData];
      let bValue = b[sortConfig.key as keyof S3ComparisonData];

      // Handle string comparison
      if (typeof aValue === 'string' && typeof bValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }, [s3Data, sortConfig]);

  // Pagination
  const totalPages = Math.ceil(sortedData.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const paginatedData = sortedData.slice(startIndex, startIndex + ITEMS_PER_PAGE);

  const handleSort = (key: string) => {
    setSortConfig(prevConfig => {
      if (prevConfig?.key === key) {
        if (prevConfig.direction === 'asc') {
          return { key, direction: 'desc' };
        } else {
          return null; // Remove sorting
        }
      }
      return { key, direction: 'asc' };
    });
  };

  const getSortIcon = (key: string) => {
    if (sortConfig?.key !== key) {
      return <ArrowUpDown className="h-4 w-4 text-muted-foreground" />;
    }
    return sortConfig.direction === 'asc' ? 
      <ArrowUpDown className="h-4 w-4 text-primary" /> : 
      <ArrowUpDown className="h-4 w-4 text-primary rotate-180" />;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          <p className="text-muted-foreground">Loading price comparison data from S3...</p>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-red-600">Error: {error}</p>
        </CardContent>
      </Card>
    );
  }

  if (sortedData.length === 0) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-muted-foreground">No price comparison data available.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Price Comparison Results</span>
          <Badge variant="secondary">{sortedData.length} comparisons</Badge>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Data source: embedding_matched_price_comparison_shopeeLotus.json
        </p>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">#</TableHead>
                <TableHead className="min-w-[300px]">Product 1</TableHead>
                <TableHead>Product 1 Price</TableHead>
                <TableHead>Product 1 Marketplace</TableHead>
                <TableHead>Product 1 URL</TableHead>
                <TableHead className="min-w-[300px]">Product 2</TableHead>
                <TableHead>Product 2 Price</TableHead>
                <TableHead>Product 2 Marketplace</TableHead>
                <TableHead>Product 2 URL</TableHead>
                <TableHead>Similarity Score</TableHead>
                <TableHead>Similarity Level</TableHead>
                <TableHead>Price Difference</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedData.map((comparison, index) => {
                console.log('Processing comparison:', comparison);

                return (
                  <TableRow key={`comparison-${startIndex + index}`}>
                    <TableCell className="font-medium">
                      {startIndex + index + 1}
                    </TableCell>
                    <TableCell className="min-w-[300px]">
                      <div className="font-medium text-sm whitespace-normal break-words">
                        {comparison.product_1}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-semibold text-green-600 dark:text-green-400">
                        {formatPrice(comparison.product_1_price)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getMarketplaceBadgeColor(comparison.product_1_marketplace)}>
                        {comparison.product_1_marketplace}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {comparison.product_1_url ? (
                        <a 
                          href={comparison.product_1_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      ) : (
                        <span className="text-muted-foreground text-xs">No URL</span>
                      )}
                    </TableCell>
                    <TableCell className="min-w-[300px]">
                      <div className="font-medium text-sm whitespace-normal break-words">
                        {comparison.product_2}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-semibold text-green-600 dark:text-green-400">
                        {formatPrice(comparison.product_2_price)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getMarketplaceBadgeColor(comparison.product_2_marketplace)}>
                        {comparison.product_2_marketplace}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {comparison.product_2_url ? (
                        <a 
                          href={comparison.product_2_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      ) : (
                        <span className="text-muted-foreground text-xs">No URL</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm font-medium text-blue-600 dark:text-blue-400">
                        {formatSimilarity(comparison.similarity_score)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={comparison.similarity_level === "Very Similar" ? "default" : "secondary"}>
                        {comparison.similarity_level}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-red-600 dark:text-red-400">
                        {formatPrice(comparison.price_difference)}
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-2 py-4">
            <div className="text-sm text-muted-foreground">
              Showing {startIndex + 1} to {Math.min(startIndex + ITEMS_PER_PAGE, sortedData.length)} of {sortedData.length} results
            </div>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              <div className="text-sm">
                Page {currentPage} of {totalPages}
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
