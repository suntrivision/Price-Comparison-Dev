
import { useState, useEffect } from "react";
import { PriceMatchProduct, CSVProduct } from "./types";

export function usePriceMatchData() {
  const [priceMatchData, setPriceMatchData] = useState<PriceMatchProduct[]>([]);
  const [csvData, setCsvData] = useState<CSVProduct[]>([]);
  const [embeddingMatchData, setEmbeddingMatchData] = useState<PriceMatchProduct[]>([]);
  const [rawEmbeddingData, setRawEmbeddingData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  const fetchEmbeddingMatchData = async () => {
    try {
      console.log('Fetching embedding match data...');
      const embeddingUrl = 'https://prodpromo.s3.ap-southeast-1.amazonaws.com/thunderbitscrape/embedding_matched_price_comparison.json';
      
      const response = await fetch(embeddingUrl);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const jsonData = await response.json();
      console.log('Raw JSON data received:', jsonData);
      
      // Store the raw JSON data
      setRawEmbeddingData(jsonData);
      
      // Get current timestamp for the run in human-readable format
      const now = new Date();
      const currentTimestamp = now.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
      const runNumber = Date.now(); // Use timestamp as run number
      
      // Handle the array structure directly
      let allProducts: any[] = [];
      
      if (Array.isArray(jsonData)) {
        jsonData.forEach((cluster: any, clusterIndex: number) => {
          // Parse the all_products string to extract individual products
          if (cluster.all_products && typeof cluster.all_products === 'string') {
            const productsText = cluster.all_products;
            const productLines = productsText.split(';').filter(line => line.trim());
            
            productLines.forEach((productLine: string, productIndex: number) => {
              const trimmedLine = productLine.trim();
              // Extract product name and price using regex
              const match = trimmedLine.match(/^(.+?)\s+-\s+RM([\d.]+)$/);
              
              if (match) {
                const [, productName, price] = match;
                allProducts.push({
                  cluster_id: cluster.cluster_id || clusterIndex,
                  representative_name: cluster.representative_name || productName.trim(),
                  name: productName.trim(),
                  price: parseFloat(price),
                  marketplace: cluster.lowest_marketplace || 'Unknown',
                  product_url: cluster.lowest_url || '',
                  image_url: '',
                  source_search_url: '',
                  size_info: '',
                  similarity_to_best_price: 100,
                  enhanced_with_image: false,
                  lowest_price: cluster.lowest_price || parseFloat(price),
                  lowest_marketplace: cluster.lowest_marketplace || 'Unknown',
                  lowest_url: cluster.lowest_url || '',
                  category: `Run#${runNumber} ${currentTimestamp}`,
                  id: `embedding-${clusterIndex}-${productIndex}`
                });
              }
            });
          }
        });
      }
      
      console.log('Processed products from clusters:', allProducts.length);
      
      // Transform the data to match our interface
      const transformedData: PriceMatchProduct[] = allProducts.map((item: any, index: number) => ({
        id: item.id || `embedding-${index}`,
        cluster_id: (item.cluster_id || 0) + 10000, // Use different cluster IDs to distinguish from original data
        representative_name: item.representative_name || item.name || `Product ${index}`,
        name: item.name || item.representative_name || `Product ${index}`,
        price: item.price || 0,
        marketplace: item.marketplace || 'Unknown',
        product_url: item.product_url || '',
        image_url: item.image_url || '',
        source_search_url: item.source_search_url || '',
        size_info: item.size_info || '',
        similarity_to_best_price: item.similarity_to_best_price || 0,
        enhanced_with_image: item.enhanced_with_image || false,
        lowest_price: item.lowest_price || item.price || 0,
        lowest_marketplace: item.lowest_marketplace || item.marketplace || 'Unknown',
        lowest_url: item.lowest_url || item.product_url || '',
        category: item.category
      }));
      
      console.log('Final transformed data:', transformedData.length, 'products');
      setEmbeddingMatchData(transformedData);
    } catch (error) {
      console.error('Error fetching embedding match data:', error);
      setEmbeddingMatchData([]);
      setRawEmbeddingData(null);
    }
  };

  const fetchData = async () => {
    setIsLoading(true);
    try {
      // Create mock data for the original price match data since the URL is not working
      console.log('Creating mock original price match data...');
      const mockPriceMatchData: PriceMatchProduct[] = [
        {
          id: "original-1",
          cluster_id: "1",
          representative_name: "Sample Product 1",
          name: "Sample Product 1",
          price: 15.99,
          marketplace: "Shopee",
          product_url: "https://shopee.com.my/sample1",
          image_url: "",
          source_search_url: "",
          size_info: "",
          similarity_to_best_price: 100,
          enhanced_with_image: false,
          lowest_price: 15.99,
          lowest_marketplace: "Shopee",
          lowest_url: "https://shopee.com.my/sample1",
          category: "original"
        },
        {
          id: "original-2",
          cluster_id: "2",
          representative_name: "Sample Product 2",
          name: "Sample Product 2",
          price: 25.50,
          marketplace: "Lazada",
          product_url: "https://lazada.com.my/sample2",
          image_url: "",
          source_search_url: "",
          size_info: "",
          similarity_to_best_price: 95,
          enhanced_with_image: false,
          lowest_price: 25.50,
          lowest_marketplace: "Lazada",
          lowest_url: "https://lazada.com.my/sample2",
          category: "original"
        }
      ];
      
      setPriceMatchData(mockPriceMatchData);

      // Create mock CSV data
      console.log('Creating mock CSV data...');
      const mockCsvData: CSVProduct[] = [
        {
          Product: "Sample Product 1",
          Shopee_Price: "RM15.99",
          Shopee_URL: "https://shopee.com.my/sample1",
          Lazada_Price: "RM18.99",
          Lazada_URL: "https://lazada.com.my/sample1",
          Mydin_Price: "N/A",
          Mydin_URL: "N/A",
          Lotus_Price: "RM25.99",
          Lotus_URL: "https://lotus.com.my/sample1",
          Aeon_Price: "N/A",
          Aeon_URL: "N/A",
          Tiktok_Price: "N/A",
          Tiktok_URL: "N/A",
          Giant_Price: "N/A",
          Giant_URL: "N/A"
        }
      ];
      
      setCsvData(mockCsvData);

      // Fetch embedding match data
      await fetchEmbeddingMatchData();

    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return {
    priceMatchData,
    csvData,
    embeddingMatchData,
    rawEmbeddingData,
    isLoading,
    refetchData: fetchData
  };
}
